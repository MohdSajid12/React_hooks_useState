import React, { useState } from 'react';
import './Counter.css';

const Counter = () =>{
    //count is a  state varible and setCount is  a function
    //we set the initile value is 0 of count
    //whenever we use setCount is 13 to seCount me 13 ajyega
    const [count , setCount] = useState(0);
    return (
        <div className='counter-container'>
            <p id="id">You have clicked {count} times</p>

            <button id="btn" onClick={() => {setCount(count+1)}}>Click Me</button>
            <button onClick={()=>setCount(0)}>Reset</button>
        </div>
    )
}

export default Counter;